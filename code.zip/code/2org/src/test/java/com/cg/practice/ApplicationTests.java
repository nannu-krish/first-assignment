package com.cg.practice;

import static org.junit.Assert.*;

import java.util.HashMap;

import junit.framework.Assert;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ApplicationTests {
	Controller controller= new Controller();
	HashMap<Integer,HelloWorldPojo> hashmap=new HashMap<Integer, HelloWorldPojo>();
	
	@Test(expected = EmptyException.class)
	public void testParticular() throws EmptyException {
		
		hashmap.put(1,new HelloWorldPojo(1,"Hi buddy"));
		
		//Assert.assertTrue(EqualsBuilder.reflectionEquals(hashmap.get(1),controller.particular(1)));
	
		assertEquals(hashmap.get(1).getId(), controller.particular(1).getId());
		assertEquals(hashmap.get(1).getId(), controller.particular(1).getId());
	}

}
