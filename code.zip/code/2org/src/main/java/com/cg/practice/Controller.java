package com.cg.practice;


import java.util.Collection;
import java.util.HashMap;















import javax.xml.ws.http.HTTPException;

import org.apache.tomcat.util.http.RequestUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;




@RestController
@RequestMapping("/hello-world-service")
public class Controller {


	HashMap<Integer,HelloWorldPojo> hashmap=new HashMap<Integer, HelloWorldPojo>();
	

	@RequestMapping(value="/Hello/hello{id}")
	public HelloWorldPojo particular(@PathVariable int id) throws EmptyException{
		
		hashmap.put(1,new HelloWorldPojo(1,"Hi buddy"));
		
		hashmap.put(2,new HelloWorldPojo(2,"How is your day"));
	
		hashmap.put(3,new HelloWorldPojo(3,"Cookies are good"));
		
		if(hashmap.get(id) == null){
			throw new EmptyException();
		}
		return hashmap.get(id);
	}
	
}
