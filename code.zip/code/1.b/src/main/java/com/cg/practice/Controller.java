package com.cg.practice;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;




@RestController
@RequestMapping("/hello-world-service")
public class Controller {
	ArrayList<HelloWorldPojo> msgs = new ArrayList<HelloWorldPojo>();
	//HashMap<Integer,HelloWorldPojo> hm=new HashMap<Integer,HelloWorldPojo>();
	
	@RequestMapping(value="/Hello",method = RequestMethod.GET)
    public ArrayList<HelloWorldPojo> retrival() throws EmptyException{
		if (msgs.isEmpty())
	    {
	       throw new EmptyException(); 
	    }
        return msgs;
        
	}

	@RequestMapping(value="/Hello",method = RequestMethod.POST)
    public String greeting(@RequestParam(value="id") int id, @RequestParam(value="message") String msg ) {
		
		HelloWorldPojo pojo= new HelloWorldPojo(id, msg);
		
	
		msgs.add(pojo);
		
		return "Stored successfully";
	}
        
}
