package com.cg.practice;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.NO_CONTENT,reason="No data to display")
public class EmptyException extends Exception{
	private static final long serialVersionUID = 100L;
}
