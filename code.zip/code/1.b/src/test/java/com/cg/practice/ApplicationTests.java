package com.cg.practice;

import java.util.ArrayList;

import junit.framework.Assert;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;

@RunWith(SpringRunner.class)
@SpringBootTest

public class ApplicationTests {

	Controller controller= new Controller();
	ArrayList<HelloWorldPojo> msgs = new ArrayList<HelloWorldPojo>();
	
	@Test
	public void testGreeting() {
		
		 String successmsg="Stored successfully";
		 int id = 1;
		 String msg="Hello World";
		 
		 Assert.assertEquals(successmsg, controller.greeting(id, msg));
		 
		}
	
	@Test(expected = EmptyException.class)
	public void testRetrival() throws EmptyException{
		int id=1;
		String msg="Hello World";
		msgs.add(new HelloWorldPojo(id, msg));
		
		Assert.assertTrue(EqualsBuilder.reflectionEquals(msgs,controller.retrival()));
		
	}

}
