package com.example.demo;

public class Helloworld {
	  long id;
	  String msg;

	    public Helloworld(long id, String msg) {
	        this.id = id;
	        this.msg = msg;
	    }

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}

	   
}
