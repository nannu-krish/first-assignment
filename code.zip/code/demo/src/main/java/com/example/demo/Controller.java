package com.example.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hello-world-service")
public class Controller {
	
	@RequestMapping("/Hello")
    public Helloworld hello(){
        return new Helloworld(1, "Hello World");
	    }
	
}

