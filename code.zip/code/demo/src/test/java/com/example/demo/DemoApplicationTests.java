package com.example.demo;

import static org.junit.Assert.assertTrue;
import junit.framework.Assert;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.assertj.core.util.diff.myers.Equalizer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoApplicationTests {

	Controller controller= new Controller();
	
	@Test
	public void testHello() {
		
		 int id = 1;
		 String msg="Hello World";
		Helloworld tom= new Helloworld(id,msg);
		//assertTrue(tom.equals(controller.hello()));
		
		Assert.assertTrue(EqualsBuilder.reflectionEquals(tom,controller.hello()));
	}

}
